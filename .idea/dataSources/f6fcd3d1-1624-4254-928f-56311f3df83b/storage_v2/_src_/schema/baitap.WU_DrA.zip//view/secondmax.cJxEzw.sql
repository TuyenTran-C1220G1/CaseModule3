create view secondmax as
select max(`baitap`.`mark`.`mark`) AS `max(mark)`
from `baitap`.`mark`
where (`baitap`.`mark`.`mark` < (select `baitap`.`firtmax`.`max(mark)` from `baitap`.`firtmax`));

