create view firtmax as
select max(`baitap`.`mark`.`mark`) AS `max(mark)`
from `baitap`.`mark`;

